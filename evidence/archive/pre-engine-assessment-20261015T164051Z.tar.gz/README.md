# Project X

A local engineering foundation for an agent-first terminal with two initial clients: host-terminal TUI and Electron desktop. **This is not a working terminal application. The serializer-based xterm replica model failed essential gate X4; dependent product work is stopped.**

Read the [engineering results and next decision](docs/engineering/18-foundation-gate-results.md) for pass/fail/not-run evidence, limits and the proposed next bounded engine assessment. The [design index](docs/index.md) links all 18 original documents, now canonical under `docs/`. No divergent root copies remain.

The actual foundation contains:

- `crates/{protocol,domain,platform,service,client,console}`: private wire contract, pure receipt/fencing model, allocation validation, offline admission, cursor reconciliation and synthetic TUI/diagnostic code.
- `apps/{desktop,engine-host}` and `packages/{protocol,terminal-adapter}`: synthetic desktop input and headless observation seams, generated bindings/validator and bounded terminal probes. Electron/React and live TUI are not implemented.
- `tests/{fixtures,system,fuzz}`, `schemas/public`, `scripts`, `evidence`: shared sanitized inputs, executable regressions, generator/provenance checks and exact result records.
- `mkdocs.yml`, pinned docs requirements, Cargo/pnpm lockfiles, local developer commands and an authored CI workflow. No keeper/broker/PTY/runtime implementation or packaging scaffold is presented as complete.

Use existing Python **3.10** with venv, Rust **1.91.0** with rustfmt/Clippy, Git and make on Linux x86_64. Bootstrap installs only the recorded project-local Node **24.21.0** and pnpm **10.32.1** tools and verified source fixtures; registry dependencies/caches stay local. Other OS/Python tuples are not qualified. No globally installed pnpm or particular shell/theme is required.

```sh
make bootstrap
make docs-install install
make verify
make provenance
make engine-gate
```

`make verify` runs foundation checks and records the known failed gate separately in [checks.json](evidence/checks.json). Its success characterizes the counterexample; **it does not pass X4**. `make engine-gate` exits nonzero for that essential failure and is separately blocking in the authored CI. That workflow has not run on a provider. `make docs` builds strict MkDocs locally into ignored `.artifacts/site`, without a web server or publication.

Useful commands: `make check test stress`, `make format`, `cargo run --locked -p project-x-console -- diagnose` (through Make's project environment), and `node scripts/generate-bindings.mjs` (pinned Node/Cargo environment). The diagnostic uses a TestBackend, prints the blocked state and never enters raw mode or starts a process/PTY.

Git was initialized locally on `main`; nothing is staged or committed, and no remote is configured. All work remains available for review. Apache-2.0 remains a recommendation; **no project license has been adopted**.
